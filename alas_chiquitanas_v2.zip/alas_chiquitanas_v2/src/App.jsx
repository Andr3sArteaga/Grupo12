import { useState } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import './App.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
    iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

function LocationMarker({ setPosition }) {
    useMapEvents({
        click(e) {
            setPosition(e.latlng);
        },
    });
    return null;
}

const RegisteredReportForm = () => {
    const [position, setPosition] = useState(null);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!position) {
            alert('Por favor, marca una ubicación en el mapa.');
            return;
        }

        console.log('Reporte enviado');
        console.log('Ubicación marcada:', position);
    };

    return (
        <div className="page-wrapper">
            <div className="form-container">
                <h2 className="form-title">Reporte de Incendio</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Fecha y hora</label>
                        <input
                            type="datetime-local"
                            value={new Date().toISOString().slice(0, 16)}
                            readOnly
                        />
                    </div>

                    <div className="form-group">
                        <label>Nombre del lugar o comunidad (opcional)</label>
                        <input type="text" />
                    </div>

                    <div className="form-group">
                        <label>Ubicación del Incendio (haz clic en el mapa para marcar)</label>
                        <div className="map-container">
                            <MapContainer center={[-17.8, -63.2]} zoom={6} style={{ height: '100%', width: '100%' }}>
                                <TileLayer
                                    attribution="&copy; OpenStreetMap"
                                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                />
                                {position && <Marker position={position} />}
                                <LocationMarker setPosition={setPosition} />
                            </MapContainer>
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Tipo de incendio</label>
                        <select required>
                            <option value="">Seleccione uno</option>
                            <option>Incendio de pastizales</option>
                            <option>Incendio en una casa</option>
                            <option>Incendio forestal</option>
                            <option>Otro</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Gravedad del incendio</label>
                        <select required>
                            <option value="">Seleccione una</option>
                            <option>Bajo</option>
                            <option>Mediano</option>
                            <option>Alto</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Comentario adicional (opcional)</label>
                        <textarea rows="3" />
                    </div>

                    <button type="submit">Enviar Reporte</button>
                </form>
            </div>
        </div>
    );
};

export default RegisteredReportForm;
